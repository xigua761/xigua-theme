<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#0B0F0D">
<script>
/* 在样式解析前落定主题，避免刷新时闪一下 */
(function(){
  var m = 'auto';
  try { m = localStorage.getItem('xg_theme') || 'auto'; } catch(e){}
  if (m !== 'light' && m !== 'dark') m = 'auto';
  document.documentElement.setAttribute('data-theme', m);
})();
</script>
<meta name="description" content="{{ $description ?? '西瓜机场 · 全球代理加速服务' }}">
<title>{{ $title ?? '西瓜机场' }}</title>
<link rel="icon" href="{{ ($logo ?? '') ?: '/theme/'.($theme ?? 'xigua').'/assets/avatar.jpg' }}">
<style>
/* ============ 设计令牌 ============ */
:root{
  --bg:#0B0F0D;
  --bg-soft:#0F1512;
  --card:#131A16;
  --card-2:#18211C;
  --line:rgba(255,255,255,.075);
  --line-strong:rgba(255,255,255,.14);
  --text:#F1F5F2;
  --muted:#8B978F;
  --faint:#5E6B64;
  --melon:#FF3B63;      /* 瓜瓤 */
  --melon-soft:#FF7A8E;
  --rind:#35D07F;       /* 瓜皮 */
  --rind-deep:#1E8A57;
  --seed:#1B1F1D;
  --warn:#FFB020;
  --danger:#FF5B5B;
  --melon-2:#FF6A4D;
  --tint-melon:rgba(255,59,99,.12);
  --tint-rind:rgba(53,208,127,.13);
  --tint-warn:rgba(255,176,32,.13);
  --tint-dim:rgba(255,255,255,.06);
  --melon-line:rgba(255,59,99,.5);
  --melon-glow:rgba(255,59,99,.75);
  --track:rgba(53,208,127,.16);
  --topbar-bg:rgba(11,15,13,.82);
  --nav-bg:rgba(19,26,22,.93);
  --glow-op:1;
  --on-accent:#fff;
  color-scheme:dark;
  --r-lg:22px; --r-md:16px; --r-sm:11px;
  --sans:system-ui,-apple-system,"PingFang SC","HarmonyOS Sans SC","Microsoft YaHei","Noto Sans SC",sans-serif;
  --mono:ui-monospace,"SF Mono","JetBrains Mono",Menlo,Consolas,monospace;
  --shadow:0 18px 40px -22px rgba(0,0,0,.9);
  --nav-shadow:0 24px 50px -20px rgba(0,0,0,.95);
}
/* 浅色令牌：手动选择浅色时 */
:root[data-theme="light"]{
  --bg:#F6F4F0;
  --bg-soft:#FFFFFF;
  --card:#FFFFFF;
  --card-2:#F0EEE9;
  --line:rgba(18,28,22,.09);
  --line-strong:rgba(18,28,22,.15);
  --text:#131A16;
  --muted:#5A6660;
  --faint:#8B958F;
  --melon:#E12448;
  --melon-2:#EF5B34;
  --melon-soft:#B81A3C;
  --rind:#158A55;
  --rind-deep:#0E6A40;
  --seed:#1E241F;
  --warn:#9A6300;
  --danger:#C42B2B;
  --tint-melon:rgba(225,36,72,.09);
  --tint-rind:rgba(21,138,85,.10);
  --tint-warn:rgba(154,99,0,.11);
  --tint-dim:rgba(18,28,22,.055);
  --melon-line:rgba(225,36,72,.42);
  --melon-glow:rgba(225,36,72,.42);
  --track:rgba(21,138,85,.15);
  --topbar-bg:rgba(246,244,240,.86);
  --nav-bg:rgba(255,255,255,.94);
  --shadow:0 16px 34px -22px rgba(18,28,22,.42);
  --nav-shadow:0 20px 44px -22px rgba(18,28,22,.5);
  --glow-op:.5;
  color-scheme:light;
}
/* 浅色令牌：跟随系统（自动模式）时 —— 内容与上面保持一致 */
@media (prefers-color-scheme: light){
  :root[data-theme="auto"]{
  --bg:#F6F4F0;
  --bg-soft:#FFFFFF;
  --card:#FFFFFF;
  --card-2:#F0EEE9;
  --line:rgba(18,28,22,.09);
  --line-strong:rgba(18,28,22,.15);
  --text:#131A16;
  --muted:#5A6660;
  --faint:#8B958F;
  --melon:#E12448;
  --melon-2:#EF5B34;
  --melon-soft:#B81A3C;
  --rind:#158A55;
  --rind-deep:#0E6A40;
  --seed:#1E241F;
  --warn:#9A6300;
  --danger:#C42B2B;
  --tint-melon:rgba(225,36,72,.09);
  --tint-rind:rgba(21,138,85,.10);
  --tint-warn:rgba(154,99,0,.11);
  --tint-dim:rgba(18,28,22,.055);
  --melon-line:rgba(225,36,72,.42);
  --melon-glow:rgba(225,36,72,.42);
  --track:rgba(21,138,85,.15);
  --topbar-bg:rgba(246,244,240,.86);
  --nav-bg:rgba(255,255,255,.94);
  --shadow:0 16px 34px -22px rgba(18,28,22,.42);
  --nav-shadow:0 20px 44px -22px rgba(18,28,22,.5);
  --glow-op:.5;
  color-scheme:light;
}
}
/* 备选：紫色（与演示站一致），把 --melon/--rind 换掉即可 */

*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;padding:0}
body{
  background:var(--bg);color:var(--text);font-family:var(--sans);
  font-size:15px;line-height:1.6;-webkit-font-smoothing:antialiased;
  padding-bottom:calc(96px + env(safe-area-inset-bottom));
}
body.no-nav{padding-bottom:32px}
a{color:inherit;text-decoration:none}
button{font-family:inherit;color:inherit;border:0;background:none;cursor:pointer}
input,textarea,select{font-family:inherit;font-size:15px}
:focus-visible{outline:2px solid var(--melon);outline-offset:2px;border-radius:8px}
::selection{background:var(--melon);color:var(--on-accent)}

/* 西瓜纹背景：极淡的斜纹，只在首屏可见 */
body::before{
  content:"";position:fixed;inset:0;pointer-events:none;z-index:0;opacity:var(--glow-op);
  background:
    radial-gradient(80% 55% at 50% -10%, rgba(255,59,99,.16), transparent 70%),
    radial-gradient(60% 40% at 100% 0%, rgba(53,208,127,.10), transparent 70%);
}
.wrap{position:relative;z-index:1;max-width:520px;margin:0 auto;padding:0 18px}
@media (min-width:900px){ .wrap{max-width:960px} }

/* ============ 通用零件 ============ */
.eyebrow{
  font-size:11px;letter-spacing:.22em;text-transform:uppercase;
  color:var(--melon-soft);font-weight:700;margin:0 0 8px
}
h1.display{
  font-size:clamp(32px,9vw,46px);line-height:1.08;letter-spacing:-.03em;
  font-weight:800;margin:0 0 14px
}
h2.sec{font-size:19px;font-weight:750;letter-spacing:-.01em;margin:0 0 4px}
.sub{color:var(--muted);margin:0 0 18px;font-size:14px}
.num{font-family:var(--mono);font-variant-numeric:tabular-nums;letter-spacing:-.02em}

.card{
  background:var(--card);border:1px solid var(--line);border-radius:var(--r-lg);
  padding:20px;box-shadow:var(--shadow);position:relative;overflow:hidden
}
.card+.card{margin-top:14px}
.card-title{font-size:17px;font-weight:750;margin:0 0 2px}
.card-desc{color:var(--muted);font-size:13px;margin:0 0 16px}

/* 统计卡：左侧瓜皮→瓜瓤渐变条（呼应演示站） */
.stat{
  background:var(--card);border:1px solid var(--line);border-radius:var(--r-lg);
  padding:20px 20px 20px 26px;position:relative;overflow:hidden
}
.stat::before{
  content:"";position:absolute;left:10px;top:16px;bottom:16px;width:4px;border-radius:4px;
  background:linear-gradient(180deg,var(--melon),var(--rind))
}
.stat .ico{
  width:44px;height:44px;border-radius:13px;display:grid;place-items:center;
  background:var(--tint-melon);color:var(--melon-soft);margin-bottom:26px
}
.stat .val{font-size:27px;font-weight:800;letter-spacing:-.02em;line-height:1.15}
.stat .lab{color:var(--faint);font-size:13px;margin-top:2px}
.stat-grid{display:grid;gap:12px}
@media (min-width:640px){ .stat-grid{grid-template-columns:repeat(2,1fr)} }
@media (min-width:900px){ .stat-grid{grid-template-columns:repeat(4,1fr)} }

.btn{
  display:inline-flex;align-items:center;justify-content:center;gap:10px;
  padding:14px 22px;border-radius:14px;font-weight:750;font-size:15px;
  background:var(--card-2);border:1px solid var(--line-strong);transition:.16s
}
.btn:hover{border-color:var(--melon);color:#fff}
.btn:active{transform:translateY(1px)}
.btn-primary{
  background:linear-gradient(135deg,var(--melon),var(--melon-2));border:0;color:var(--on-accent);
  box-shadow:0 12px 30px -12px var(--melon-glow)
}
.btn-primary:hover{filter:brightness(1.07);color:var(--on-accent)}
.btn-ghost{background:transparent;border:1px solid var(--line-strong)}
.btn-sm{padding:9px 15px;font-size:13px;border-radius:11px}
.btn-block{display:flex;width:100%}
.btn[disabled]{opacity:.45;pointer-events:none}
.btn-row{display:flex;gap:10px;flex-wrap:wrap}

.tag{
  display:inline-flex;align-items:center;gap:6px;padding:4px 10px;border-radius:999px;
  font-size:12px;font-weight:700;background:var(--tint-rind);color:var(--rind)
}
.tag.warn{background:var(--tint-warn);color:var(--warn)}
.tag.dim{background:var(--tint-dim);color:var(--muted)}
.tag.melon{background:var(--tint-melon);color:var(--melon-soft)}

.row{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:14px 0;border-bottom:1px dashed var(--line)}
.row:last-child{border-bottom:0}
.row .k{color:var(--muted);font-size:14px}
.row .v{font-weight:750}

.field{margin-bottom:14px}
.field label{display:block;font-size:13px;color:var(--muted);margin-bottom:7px;font-weight:600}
.field input,.field textarea,.field select{
  width:100%;padding:14px 15px;border-radius:13px;background:var(--bg-soft);
  border:1px solid var(--line-strong);color:var(--text);outline:none;transition:.15s
}
.field input:focus,.field textarea:focus,.field select:focus{border-color:var(--melon)}
.field textarea{min-height:120px;resize:vertical}

.empty{text-align:center;padding:48px 20px;color:var(--muted)}
.empty .dot{
  width:58px;height:58px;border-radius:50%;margin:0 auto 16px;display:grid;place-items:center;
  border:2px solid var(--melon);color:var(--melon)
}
.empty h3{margin:0 0 6px;color:var(--text);font-size:19px;font-weight:750}
.empty p{margin:0 auto 20px;max-width:300px;font-size:14px}

.skeleton{
  height:88px;border-radius:var(--r-lg);
  background:linear-gradient(100deg,var(--card) 30%,var(--card-2) 50%,var(--card) 70%);
  background-size:220% 100%;animation:sk 1.3s linear infinite
}
@keyframes sk{to{background-position:-120% 0}}

/* ============ 顶栏 ============ */
.topbar{
  position:sticky;top:0;z-index:40;backdrop-filter:blur(18px);
  background:var(--topbar-bg);border-bottom:1px solid var(--line)
}
.topbar .inner{display:flex;align-items:center;gap:12px;padding:14px 18px;max-width:960px;margin:0 auto}
.brand{display:flex;align-items:center;gap:11px;margin-right:auto}
.brand .mark{
  width:40px;height:40px;border-radius:13px;flex:none;overflow:hidden;
  background:#fff;border:1px solid var(--line-strong);
  box-shadow:0 8px 22px -10px var(--tint-rind)
}
.brand .mark img{width:100%;height:100%;display:block;object-fit:cover}
.theme-btn{
  width:38px;height:38px;border-radius:12px;display:grid;place-items:center;flex:none;
  border:1px solid var(--line-strong);color:var(--muted);transition:.16s
}
.theme-btn:hover{color:var(--melon-soft);border-color:var(--melon)}
.brand .nm{font-size:17px;font-weight:800;letter-spacing:-.01em;line-height:1.1}
.brand .sl{font-size:10px;letter-spacing:.2em;color:var(--faint);text-transform:uppercase;font-weight:700}

/* ============ 底部标签栏 ============ */
.tabbar{
  position:fixed;left:0;right:0;bottom:0;z-index:50;
  padding:0 14px calc(14px + env(safe-area-inset-bottom))
}
.tabbar .pill{
  max-width:492px;margin:0 auto;display:grid;grid-template-columns:repeat(6,1fr);
  background:var(--nav-bg);backdrop-filter:blur(20px);
  border:1px solid var(--line-strong);border-radius:24px;padding:8px 6px;
  box-shadow:var(--nav-shadow)
}
.tabbar a{
  display:flex;flex-direction:column;align-items:center;gap:5px;padding:9px 2px;
  border-radius:16px;color:var(--faint);font-size:11px;font-weight:650;transition:.16s
}
.tabbar a.on{color:var(--melon-soft);background:var(--tint-melon)}
.tabbar svg{width:21px;height:21px}

/* ============ 流量环（西瓜切片） ============ */
.donut{position:relative;width:210px;height:210px;margin:6px auto 22px}
.donut svg{transform:rotate(-90deg);width:100%;height:100%}
.donut .track{stroke:var(--track)}
#melonGrad stop:first-child{stop-color:var(--melon)}
#melonGrad stop:last-child{stop-color:var(--melon-2)}
.donut .prog{stroke:url(#melonGrad);stroke-linecap:round;transition:stroke-dasharray .9s cubic-bezier(.22,1,.36,1)}
.donut .mid{
  position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center
}
.donut .pct{font-size:40px;font-weight:800;letter-spacing:-.04em}
.donut .cap{font-size:12px;color:var(--faint);letter-spacing:.06em}
.seeds{position:absolute;inset:0;pointer-events:none}
.seeds i{
  position:absolute;width:7px;height:11px;border-radius:50% 50% 45% 45%;
  background:var(--seed);border:1px solid var(--line-strong)
}

/* ============ 订阅链接 ============ */
.sub-url{
  display:flex;gap:10px;align-items:center;background:var(--bg-soft);
  border:1px solid var(--line-strong);border-radius:14px;padding:13px 15px
}
.sub-url code{
  font-family:var(--mono);font-size:12.5px;color:var(--muted);
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex:1
}
.qr{background:#fff;padding:12px;border-radius:16px;width:max-content;margin:16px auto 0;border:1px solid var(--line-strong)}
.qr img,.qr canvas{display:block;width:172px;height:172px;image-rendering:pixelated}
.clients{display:grid;grid-template-columns:repeat(auto-fit,minmax(96px,1fr));gap:9px;margin-top:14px}
.clients a{
  text-align:center;padding:11px 6px;border-radius:12px;background:var(--card-2);
  border:1px solid var(--line);font-size:13px;font-weight:650
}
.clients a:hover{border-color:var(--melon)}

/* ============ 套餐 ============ */
.plan{border:1px solid var(--line);border-radius:var(--r-lg);background:var(--card);padding:22px;position:relative}
.plan+.plan{margin-top:14px}
.plan.hot{border-color:var(--melon-line)}
.plan.hot::after{
  content:"推荐";position:absolute;top:16px;right:16px;font-size:11px;font-weight:800;
  padding:4px 10px;border-radius:999px;background:var(--melon);color:var(--on-accent);letter-spacing:.05em
}
.plan h3{margin:0 0 6px;font-size:20px;font-weight:800}
.plan .price{display:flex;align-items:baseline;gap:6px;margin:12px 0 4px}
.plan .price b{font-size:34px;font-weight:800;letter-spacing:-.03em}
.plan .price span{color:var(--faint);font-size:13px}
.plan .body{color:var(--muted);font-size:14px;margin:12px 0 16px}
.plan .body ul{padding-left:18px;margin:8px 0}
.periods{display:flex;gap:8px;flex-wrap:wrap;margin:14px 0 16px}
.periods button{
  padding:9px 14px;border-radius:11px;border:1px solid var(--line-strong);
  font-size:13px;font-weight:700;color:var(--muted)
}
.periods button.on{border-color:var(--melon);color:var(--text);background:var(--tint-melon)}

/* ============ 列表项 ============ */
.item{
  display:flex;align-items:center;gap:14px;padding:16px;border-radius:var(--r-md);
  background:var(--card);border:1px solid var(--line)
}
.item+.item{margin-top:10px}
.item .main{flex:1;min-width:0}
.item .t{font-weight:750;font-size:15px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.item .s{color:var(--faint);font-size:12.5px;margin-top:3px;font-family:var(--mono)}

/* 节点 */
.node{display:flex;align-items:center;gap:12px;padding:13px 0;border-bottom:1px dashed var(--line)}
.node:last-child{border-bottom:0}
.node .led{width:8px;height:8px;border-radius:50%;background:var(--rind);flex:none;box-shadow:0 0 0 4px var(--tint-rind)}
.node .led.off{background:var(--faint);box-shadow:0 0 0 4px var(--tint-dim)}
.node .nm{flex:1;min-width:0;font-weight:650;font-size:14.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.node .rt{font-family:var(--mono);font-size:12.5px;color:var(--faint)}

/* 工单会话 */
.msg{max-width:86%;padding:12px 15px;border-radius:16px;margin-bottom:10px;font-size:14.5px;line-height:1.55;white-space:pre-wrap;word-break:break-word}
.msg.me{margin-left:auto;background:linear-gradient(135deg,var(--melon),var(--melon-2));color:var(--on-accent);border-bottom-right-radius:5px}
.msg.them{background:var(--card-2);border:1px solid var(--line);border-bottom-left-radius:5px}
.msg .ts{display:block;font-size:11px;opacity:.6;margin-top:6px;font-family:var(--mono)}

/* 公告 */
.notice{display:flex;gap:14px;align-items:flex-start}
.notice .bell{color:var(--melon-soft);flex:none;margin-top:2px}
.notice .body{font-size:14px;color:var(--muted);line-height:1.7;max-height:132px;overflow:hidden;position:relative;transition:max-height .3s}
.notice .body.open{max-height:none}
.notice .body::after{content:"";position:absolute;left:0;right:0;bottom:0;height:44px;background:linear-gradient(transparent,var(--card))}
.notice .body.open::after{display:none}
.notice .body img{max-width:100%;border-radius:10px}

/* 提示条 */
#toast{
  position:fixed;left:50%;bottom:110px;transform:translate(-50%,20px);z-index:99;
  background:var(--card-2);border:1px solid var(--line-strong);border-radius:14px;
  padding:12px 20px;font-size:14px;font-weight:650;opacity:0;pointer-events:none;
  transition:.24s;box-shadow:var(--shadow);max-width:88vw;text-align:center
}
#toast.show{opacity:1;transform:translate(-50%,0)}
#toast.err{border-color:var(--danger);color:#FFC7C7}

/* 落地页 */
.hero{padding:34px 0 10px}
.hero p.lead{color:var(--muted);font-size:16px;line-height:1.75;margin:0 0 24px}
.feat{display:grid;gap:12px;margin-top:14px}
@media (min-width:760px){ .feat{grid-template-columns:repeat(2,1fr)} }
.feat .card .fi{
  width:46px;height:46px;border-radius:14px;display:grid;place-items:center;
  background:var(--tint-rind);color:var(--rind);margin-bottom:14px
}
.regions{display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin-top:14px}
.regions div{
  padding:14px;border-radius:14px;background:var(--card);border:1px solid var(--line);
  text-align:center;font-weight:700;font-size:14px
}
.footer{text-align:center;color:var(--faint);font-size:12.5px;padding:36px 0 20px}

@media (prefers-reduced-motion:reduce){
  *{animation-duration:.01ms !important;transition-duration:.01ms !important}
}
</style>
</head>
<body>

<div id="app"><div class="wrap"><div style="padding:80px 0"><div class="skeleton"></div></div></div></div>
<div id="toast"></div>

<svg width="0" height="0" style="position:absolute" aria-hidden="true">
  <defs>
    <linearGradient id="melonGrad" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#FF3B63"/>
      <stop offset="100%" stop-color="#FF6A4D"/>
    </linearGradient>
  </defs>
</svg>

<script>
window.XG = {
  title: @json($title ?? '西瓜机场'),
  description: @json($description ?? '面向日常浏览、远程办公、流媒体和跨境访问的稳定代理网络。'),
  logo: @json($logo ?? ''),
  version: @json($version ?? '1.0.0'),
  assets: @json('/theme/'.($theme ?? 'xigua').'/assets'),
  brandName: @json($theme_config['brand_name'] ?? ''),
  supportUrl: @json($theme_config['support_url'] ?? ''),
  telegramUrl: @json($theme_config['telegram_url'] ?? ''),
  tutorialUrl: @json($theme_config['tutorial_url'] ?? ''),
  heroTitle: @json($theme_config['hero_title'] ?? ''),
  accent: @json($theme_config['accent'] ?? 'melon')
};
</script>
<script src="{{ '/theme/'.($theme ?? 'xigua').'/assets/qrcode.js' }}?v={{ $version ?? '1' }}"></script>
<script>
(function(){
"use strict";

/* ---------------- 基础工具 ---------------- */
var BRAND = window.XG.brandName || window.XG.title || '西瓜机场';
var LOGO = window.XG.logo || (window.XG.assets + '/avatar.jpg');
var TOKEN_KEY = 'xg_auth';
var app = document.getElementById('app');

if (window.XG.accent === 'purple') {
  var rs = document.documentElement.style;
  rs.setProperty('--melon', '#7C5CFF');
  rs.setProperty('--melon-2', '#5B8CFF');
  rs.setProperty('--melon-soft', '#A794FF');
  rs.setProperty('--rind', '#3ED6C0');
  rs.setProperty('--rind-deep', '#1F8C82');
  rs.setProperty('--tint-melon', 'rgba(124,92,255,.13)');
  rs.setProperty('--tint-rind', 'rgba(62,214,192,.13)');
  rs.setProperty('--melon-line', 'rgba(124,92,255,.5)');
  rs.setProperty('--melon-glow', 'rgba(124,92,255,.6)');
  rs.setProperty('--track', 'rgba(62,214,192,.16)');
}

/* ---------------- 深浅色：自动 / 浅色 / 深色 ---------------- */
var THEME_KEY = 'xg_theme';
var THEME_MODES = [
  { k:'auto',  n:'自动',  d:'跟随系统' },
  { k:'light', n:'浅色',  d:'始终浅色' },
  { k:'dark',  n:'深色',  d:'始终深色' }
];
var mqLight = window.matchMedia ? window.matchMedia('(prefers-color-scheme: light)') : null;

function themeMode(){
  var m;
  try { m = localStorage.getItem(THEME_KEY); } catch(e){}
  return (m === 'light' || m === 'dark') ? m : 'auto';
}
function themeIsLight(){
  var m = themeMode();
  if (m === 'light') return true;
  if (m === 'dark') return false;
  return !!(mqLight && mqLight.matches);
}
function applyTheme(mode){
  document.documentElement.setAttribute('data-theme', mode);
  try { localStorage.setItem(THEME_KEY, mode); } catch(e){}
  var meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', themeIsLight() ? '#F6F4F0' : '#0B0F0D');
}
function cycleTheme(){
  var cur = themeMode();
  var i = 0;
  for (var x = 0; x < THEME_MODES.length; x++) { if (THEME_MODES[x].k === cur) i = x; }
  var next = THEME_MODES[(i + 1) % THEME_MODES.length];
  applyTheme(next.k);
  var btn = document.querySelector('[data-act="theme"]');
  if (btn) { btn.innerHTML = ic(themeIcon(), 19); btn.title = '外观：' + next.n + '（' + next.d + '）'; }
  toast('外观：' + next.n + ' · ' + next.d);
}
function themeIcon(){
  var m = themeMode();
  return m === 'light' ? 'sun' : (m === 'dark' ? 'moon' : 'auto');
}
if (mqLight) {
  var onSysChange = function(){ if (themeMode() === 'auto') applyTheme('auto'); };
  if (mqLight.addEventListener) mqLight.addEventListener('change', onSysChange);
  else if (mqLight.addListener) mqLight.addListener(onSysChange);
}

function esc(s){
  return String(s == null ? '' : s)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}
function token(){ return localStorage.getItem(TOKEN_KEY) || ''; }
function setToken(v){ v ? localStorage.setItem(TOKEN_KEY, v) : localStorage.removeItem(TOKEN_KEY); }

var toastEl = document.getElementById('toast'), toastTimer;
function toast(msg, isErr){
  toastEl.textContent = msg;
  toastEl.className = 'show' + (isErr ? ' err' : '');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(function(){ toastEl.className = ''; }, 2600);
}

function api(path, body, method){
  var headers = { 'Accept': 'application/json' };
  if (body) headers['Content-Type'] = 'application/json';
  var t = token();
  if (t) { headers['Authorization'] = t; }
  return fetch('/api/v1' + path, {
    method: method || (body ? 'POST' : 'GET'),
    headers: headers,
    body: body ? JSON.stringify(body) : undefined,
    credentials: 'include'
  }).then(function(res){
    return res.json().catch(function(){ return {}; }).then(function(json){
      if (res.status === 401 || res.status === 403) {
        setToken('');
        if (location.hash.indexOf('#/login') !== 0) go('/login');
        throw new Error(json.message || '登录已失效，请重新登录');
      }
      if (!res.ok || json.error) {
        var m = json.message || json.error ||
          (json.errors ? Object.keys(json.errors).map(function(k){ return json.errors[k]; }).join('；') : '');
        throw new Error(m || ('请求失败（' + res.status + '）'));
      }
      return json.data !== undefined ? json.data : json;
    });
  });
}

function bytes(n){
  n = Number(n) || 0;
  if (n <= 0) return '0 B';
  var u = ['B','KB','MB','GB','TB','PB'], i = 0;
  while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
  return (n >= 100 || i === 0 ? Math.round(n) : n.toFixed(n >= 10 ? 1 : 2)) + ' ' + u[i];
}
function yuan(fen){ return '¥' + ((Number(fen) || 0) / 100).toFixed(2).replace(/\.00$/, ''); }
function date(ts, withTime){
  if (!ts) return '—';
  var d = new Date(String(ts).length > 10 ? Number(ts) : Number(ts) * 1000);
  var p = function(x){ return x < 10 ? '0' + x : '' + x; };
  var s = d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
  return withTime ? s + ' ' + p(d.getHours()) + ':' + p(d.getMinutes()) : s;
}
function daysLeft(ts){
  if (!ts) return null;
  return Math.ceil((Number(ts) * 1000 - Date.now()) / 86400000);
}
function copy(text){
  var done = function(){ toast('已复制到剪贴板'); };
  if (navigator.clipboard && window.isSecureContext) {
    navigator.clipboard.writeText(text).then(done).catch(function(){ fallback(); });
  } else { fallback(); }
  function fallback(){
    var ta = document.createElement('textarea');
    ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); done(); }
    catch (e) { toast('复制失败，请长按手动选择', true); }
    document.body.removeChild(ta);
  }
}
function go(path){ location.hash = '#' + path; }

/* ---------------- 图标 ---------------- */
var I = {
  home:'<path d="M3 9.5 12 3l9 6.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
  sub:'<path d="M4 7h16M4 12h11M4 17h7"/><circle cx="19" cy="17" r="2"/>',
  order:'<path d="M6 3h12v18l-3-2-3 2-3-2-3 2z"/><path d="M9 8h6M9 12h6"/>',
  invite:'<circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.3 2.7-5.5 6-5.5s6 2.2 6 5.5"/><path d="M18 8v6M15 11h6"/>',
  ticket:'<path d="M4 5h16v11H9l-5 4z"/>',
  me:'<circle cx="12" cy="8" r="3.6"/><path d="M4.5 20c0-4 3.4-6.5 7.5-6.5S19.5 16 19.5 20"/>',
  wifi:'<path d="M2.5 9a15 15 0 0 1 19 0"/><path d="M6 12.5a10 10 0 0 1 12 0"/><path d="M9.3 16a5 5 0 0 1 5.4 0"/><circle cx="12" cy="19.5" r="1.1" fill="currentColor" stroke="none"/>',
  chart:'<path d="M4 20V10M9.3 20V5M14.7 20v-8M20 20v-4"/>',
  cal:'<rect x="3.5" y="5" width="17" height="16" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4"/>',
  wallet:'<rect x="3" y="6" width="18" height="13" rx="2.5"/><path d="M3 10h18"/><circle cx="17" cy="14.5" r="1.2" fill="currentColor" stroke="none"/>',
  bell:'<path d="M18 8a6 6 0 1 0-12 0c0 6-2 7-2 7h16s-2-1-2-7"/><path d="M10.3 19a2 2 0 0 0 3.4 0"/>',
  copy:'<rect x="9" y="9" width="11" height="11" rx="2.5"/><path d="M5 15V5.5A1.5 1.5 0 0 1 6.5 4H15"/>',
  check:'<circle cx="12" cy="12" r="9"/><path d="M8.5 12.3l2.4 2.4 4.6-4.9"/>',
  info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v5.5M12 7.8v.4"/>',
  head:'<path d="M4 14v-2a8 8 0 0 1 16 0v2"/><rect x="2.5" y="13.5" width="4" height="6.5" rx="2"/><rect x="17.5" y="13.5" width="4" height="6.5" rx="2"/>',
  globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.6 2.6 4 5.6 4 9s-1.4 6.4-4 9c-2.6-2.6-4-5.6-4-9s1.4-6.4 4-9z"/>',
  arrow:'<path d="M5 12h13M13 6l6 6-6 6"/>',
  back:'<path d="M19 12H6M11 6l-6 6 6 6"/>',
  refresh:'<path d="M20 11a8 8 0 1 0-.8 4.5"/><path d="M20 5v6h-6"/>',
  layers:'<path d="M12 3.5 3 8l9 4.5L21 8z"/><path d="M3 13l9 4.5L21 13"/>',
  moon:'<path d="M20 14.5A8.5 8.5 0 0 1 9.5 4a8.5 8.5 0 1 0 10.5 10.5z"/>',
  sun:'<circle cx="12" cy="12" r="4.2"/><path d="M12 2.5v2.2M12 19.3v2.2M4.2 4.2l1.6 1.6M18.2 18.2l1.6 1.6M2.5 12h2.2M19.3 12h2.2M4.2 19.8l1.6-1.6M18.2 5.8l1.6-1.6"/>',
  auto:'<circle cx="12" cy="12" r="8.6"/><path d="M12 3.4a8.6 8.6 0 0 1 0 17.2z" fill="currentColor" stroke="none"/>'
};
function ic(name, size){
  return '<svg viewBox="0 0 24 24" width="' + (size || 22) + '" height="' + (size || 22) +
    '" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">' +
    (I[name] || '') + '</svg>';
}

/* ---------------- 布局骨架 ---------------- */
function topbar(){
  var mark = '<span class="mark"><img src="' + esc(LOGO) + '" alt="' + esc(BRAND) + '"></span>';
  return '<header class="topbar"><div class="inner">' +
    '<a class="brand" href="#/">' + mark +
      '<span><span class="nm">' + esc(BRAND) + '</span><br><span class="sl">Control Center</span></span>' +
    '</a>' +
    '<button class="theme-btn" data-act="theme" title="外观：' + themeLabel() + '" aria-label="切换外观">' +
      ic(themeIcon(), 19) + '</button>' +
    (token()
      ? '<button class="btn btn-sm btn-ghost" data-act="reload">' + ic('refresh', 15) + '刷新</button>'
      : '<a class="btn btn-sm btn-ghost" href="#/login">登录</a><a class="btn btn-sm btn-primary" href="#/register">注册</a>') +
  '</div></header>';
}

function themeLabel(){
  var m = themeMode();
  for (var i = 0; i < THEME_MODES.length; i++) {
    if (THEME_MODES[i].k === m) return THEME_MODES[i].n + '（' + THEME_MODES[i].d + '）';
  }
  return '自动';
}

var TABS = [
  { p:'/',       n:'首页', i:'home' },
  { p:'/plan',   n:'订阅', i:'sub' },
  { p:'/order',  n:'订单', i:'order' },
  { p:'/invite', n:'推广', i:'invite' },
  { p:'/ticket', n:'工单', i:'ticket' },
  { p:'/me',     n:'我的', i:'me' }
];
function tabbar(active){
  var html = TABS.map(function(t){
    var on = (t.p === '/' ? active === '/' : active.indexOf(t.p) === 0) ? ' class="on"' : '';
    return '<a href="#' + t.p + '"' + on + '>' + ic(t.i, 21) + '<span>' + t.n + '</span></a>';
  }).join('');
  return '<nav class="tabbar"><div class="pill">' + html + '</div></nav>';
}

function render(bodyHtml, opts){
  opts = opts || {};
  document.body.classList.toggle('no-nav', !!opts.noNav);
  app.innerHTML = (opts.bare ? '' : topbar()) +
    '<main class="wrap">' + bodyHtml + '</main>' +
    (opts.noNav ? '' : tabbar(opts.active || currentPath()));
  window.scrollTo(0, 0);
}
function sectionHead(title, desc){
  return '<div style="padding:26px 0 16px"><h2 class="sec">' + esc(title) + '</h2>' +
    (desc ? '<p class="sub">' + esc(desc) + '</p>' : '') + '</div>';
}
function loading(){
  return '<div style="padding:30px 0"><div class="skeleton"></div>' +
    '<div class="skeleton" style="margin-top:14px"></div>' +
    '<div class="skeleton" style="margin-top:14px"></div></div>';
}
function errorBox(msg, retryHash){
  return '<div class="card" style="margin-top:26px"><div class="empty" style="padding:26px 0">' +
    '<div class="dot">' + ic('info', 24) + '</div><h3>没能加载出来</h3><p>' + esc(msg) + '</p>' +
    '<button class="btn btn-sm" data-act="reload">重试</button></div></div>';
}

/* ---------------- 落地页 ---------------- */
function pageLanding(){
  var regions = ['香港 · IPLC','日本 · 东京','新加坡 · SG','台湾 · 台北','美国 · 洛杉矶','韩国 · 首尔','英国 · 伦敦','德国 · 法兰克福'];
  var feats = [
    { i:'wifi',   t:'高速代理线路',   d:'常用地区节点统一管理，适合浏览、办公、开发资料访问和流媒体使用。' },
    { i:'copy',   t:'一键订阅导入',   d:'登录后复制订阅链接，导入主流客户端即可同步节点和策略。' },
    { i:'check',  t:'节点状态透明',   d:'在线状态、节点倍率、协议类型和最近检测时间清楚展示。' },
    { i:'head',   t:'服务支持入口',   d:'遇到连接、订阅或客户端问题，可以通过工单和客服入口处理。' }
  ];
  var links = '';
  if (window.XG.supportUrl)  links += '<a class="btn btn-sm" target="_blank" rel="noopener" href="' + esc(window.XG.supportUrl) + '">' + ic('head', 16) + '客服</a>';
  if (window.XG.telegramUrl) links += '<a class="btn btn-sm" target="_blank" rel="noopener" href="' + esc(window.XG.telegramUrl) + '">' + ic('head', 16) + 'TG 群</a>';

  render(
    '<section class="hero">' +
      '<p class="eyebrow">' + esc(BRAND) + ' proxy network</p>' +
      '<h1 class="display">' + esc(window.XG.heroTitle || (BRAND + ' 全球代理加速服务')) + '</h1>' +
      '<p class="lead">' + esc(window.XG.description) + '</p>' +
      '<div class="btn-row">' +
        '<a class="btn btn-primary" href="#/">进入用户中心' + ic('arrow', 17) + '</a>' +
        '<a class="btn" href="#/register">注册账号</a>' +
      '</div>' +
      (links ? '<div class="btn-row" style="margin-top:12px">' + links + '</div>' : '') +
    '</section>' +

    '<div class="card" style="margin-top:26px">' +
      '<h3 class="card-title">覆盖常用地区</h3>' +
      '<p class="card-desc">节点按地区分组，订阅更新后自动同步到客户端。</p>' +
      '<div class="regions">' + regions.map(function(r){ return '<div>' + esc(r) + '</div>'; }).join('') + '</div>' +
    '</div>' +

    sectionHead('为什么选这里', '把复杂的部分留给我们，你只需要复制一次订阅链接。') +
    '<div class="feat">' + feats.map(function(f){
      return '<div class="card"><div class="fi">' + ic(f.i, 22) + '</div>' +
        '<h3 class="card-title">' + f.t + '</h3><p class="card-desc" style="margin:0">' + f.d + '</p></div>';
    }).join('') + '</div>' +

    '<div class="footer">© ' + new Date().getFullYear() + ' ' + esc(BRAND) + ' · v' + esc(window.XG.version) + '</div>',
    { noNav:true }
  );
}

/* ---------------- 登录 / 注册 ---------------- */
function authShell(title, desc, inner, footer){
  render(
    '<section style="padding:38px 0 22px">' +
      '<p class="eyebrow">' + esc(BRAND) + '</p>' +
      '<h1 class="display" style="font-size:clamp(28px,7.5vw,38px)">' + esc(title) + '</h1>' +
      '<p class="sub" style="margin-bottom:26px">' + esc(desc) + '</p>' +
      '<div class="card">' + inner + '</div>' +
      '<p style="text-align:center;color:var(--muted);font-size:14px;margin-top:20px">' + footer + '</p>' +
    '</section>',
    { noNav:true }
  );
}
function pageLogin(){
  authShell('登录用户中心', '用注册时填写的邮箱登录，订阅和账单都在这里。',
    '<div class="field"><label for="li-email">邮箱</label><input id="li-email" type="email" autocomplete="username" placeholder="you@@example.com"></div>' +
    '<div class="field"><label for="li-pass">密码</label><input id="li-pass" type="password" autocomplete="current-password" placeholder="输入密码"></div>' +
    '<button class="btn btn-primary btn-block" data-act="login">登录</button>',
    '还没有账号？<a href="#/register" style="color:var(--melon-soft);font-weight:700">注册一个</a> · <a href="#/landing" style="color:var(--muted)">返回首页</a>'
  );
  var run = function(e){ if (e.key === 'Enter') doLogin(); };
  document.getElementById('li-email').addEventListener('keydown', run);
  document.getElementById('li-pass').addEventListener('keydown', run);
}
function doLogin(){
  var email = (document.getElementById('li-email').value || '').trim();
  var pass = document.getElementById('li-pass').value || '';
  if (!email || !pass) return toast('请把邮箱和密码填完整', true);
  var btn = document.querySelector('[data-act="login"]');
  btn.disabled = true; btn.textContent = '登录中…';
  api('/passport/auth/login', { email: email, password: pass })
    .then(function(d){
      setToken(d.auth_data || d.token || '');
      toast('登录成功');
      go('/');
    })
    .catch(function(e){
      toast(e.message, true);
      btn.disabled = false; btn.textContent = '登录';
    });
}
function pageRegister(){
  var code = (location.hash.split('code=')[1] || '').split('&')[0];
  authShell('注册账号', '注册后即可选择套餐并获取订阅链接。',
    '<div class="field"><label for="rg-email">邮箱</label><input id="rg-email" type="email" autocomplete="username" placeholder="you@@example.com"></div>' +
    '<div class="field"><label for="rg-pass">设置密码</label><input id="rg-pass" type="password" autocomplete="new-password" placeholder="至少 8 位"></div>' +
    '<div class="field"><label for="rg-vcode">邮箱验证码（站点未开启时留空）</label>' +
      '<div style="display:flex;gap:9px"><input id="rg-vcode" inputmode="numeric" placeholder="6 位数字">' +
      '<button class="btn btn-sm" style="flex:none" data-act="sendcode">发送</button></div></div>' +
    '<div class="field"><label for="rg-invite">邀请码（选填）</label><input id="rg-invite" value="' + esc(code) + '" placeholder="填写可获得优惠"></div>' +
    '<button class="btn btn-primary btn-block" data-act="register">创建账号</button>',
    '已有账号？<a href="#/login" style="color:var(--melon-soft);font-weight:700">去登录</a>'
  );
}
function doRegister(){
  var email = (document.getElementById('rg-email').value || '').trim();
  var pass = document.getElementById('rg-pass').value || '';
  var vcode = (document.getElementById('rg-vcode').value || '').trim();
  var invite = (document.getElementById('rg-invite').value || '').trim();
  if (!email || pass.length < 8) return toast('邮箱必填，密码至少 8 位', true);
  var btn = document.querySelector('[data-act="register"]');
  btn.disabled = true; btn.textContent = '创建中…';
  var body = { email: email, password: pass };
  if (vcode) body.email_code = vcode;
  if (invite) body.invite_code = invite;
  api('/passport/auth/register', body)
    .then(function(d){
      setToken(d.auth_data || d.token || '');
      toast('账号已创建');
      go('/');
    })
    .catch(function(e){
      toast(e.message, true);
      btn.disabled = false; btn.textContent = '创建账号';
    });
}
function sendCode(){
  var email = (document.getElementById('rg-email').value || '').trim();
  if (!email) return toast('先填邮箱', true);
  var btn = document.querySelector('[data-act="sendcode"]');
  btn.disabled = true;
  api('/passport/comm/sendEmailVerify', { email: email })
    .then(function(){
      toast('验证码已发送，查收邮箱');
      var left = 60;
      var t = setInterval(function(){
        btn.textContent = (--left) + 's';
        if (left <= 0) { clearInterval(t); btn.disabled = false; btn.textContent = '发送'; }
      }, 1000);
    })
    .catch(function(e){ toast(e.message, true); btn.disabled = false; });
}

/* ---------------- 首页 ---------------- */
function pageHome(){
  render(loading(), { active:'/' });
  Promise.all([
    api('/user/getSubscribe'),
    api('/user/info').catch(function(){ return {}; }),
    api('/user/notice/fetch').catch(function(){ return { data: [] }; })
  ]).then(function(r){
    var sub = r[0] || {}, info = r[1] || {}, notices = (r[2] && r[2].data) || r[2] || [];
    var used = (Number(sub.u) || 0) + (Number(sub.d) || 0);
    var total = Number(sub.transfer_enable) || 0;
    var pct = total > 0 ? Math.min(100, used / total * 100) : 0;
    var planName = sub.plan && sub.plan.name ? sub.plan.name : '';
    var left = daysLeft(sub.expired_at);
    var nick = (sub.email || info.email || '').split('@')[0] || '用户';

    NOTICES = Array.isArray(notices) ? notices : [];
    noticeIdx = 0;
    var noticeHtml = noticeCard();

    var seeds = '';
    for (var s = 0; s < 5; s++) {
      var ang = (-58 + s * 29) * Math.PI / 180, rr = 60;
      seeds += '<i style="left:' + (105 + Math.cos(ang) * rr - 3.5) + 'px;top:' + (105 + Math.sin(ang) * rr - 5.5) +
        'px;transform:rotate(' + (ang * 180 / Math.PI + 90) + 'deg)"></i>';
    }
    var C = 2 * Math.PI * 88;

    render(
      '<section style="padding:26px 0 8px">' +
        '<p class="eyebrow">Overview</p>' +
        '<h1 class="display">你好，' + esc(nick) + '</h1>' +
        '<p class="sub">这里是你的连接状态与订阅概览。</p>' +
        '<div class="btn-row"><a class="btn btn-primary" href="#/plan">查看套餐' + ic('arrow', 17) + '</a>' +
        '<a class="btn" href="#/nodes">节点状态</a></div>' +
      '</section>' +

      noticeHtml +

      '<div class="stat-grid" style="margin-top:14px">' +
        statCard('wifi',   planName || '未订阅', '当前订阅') +
        statCard('chart',  total > 0 ? bytes(Math.max(0, total - used)) : '暂无', '剩余流量') +
        statCard('cal',    sub.expired_at ? (left > 0 ? left + ' 天' : '已到期') : (planName ? '长期有效' : '未订阅'), '订阅到期') +
        statCard('wallet', yuan(info.balance || 0), '账户余额') +
      '</div>' +

      '<div class="card" style="margin-top:14px">' +
        '<h3 class="card-title">流量使用</h3>' +
        '<p class="card-desc">上传与下载流量合计</p>' +
        '<span class="tag' + (pct > 85 ? ' warn' : '') + '">已使用 ' + pct.toFixed(0) + '%</span>' +
        '<div class="donut">' +
          '<svg viewBox="0 0 210 210">' +
            '<circle class="track" cx="105" cy="105" r="88" fill="none" stroke-width="15"/>' +
            '<circle class="prog" cx="105" cy="105" r="88" fill="none" stroke-width="15" ' +
              'stroke-dasharray="' + (C * pct / 100).toFixed(1) + ' ' + C.toFixed(1) + '"/>' +
          '</svg>' +
          '<div class="seeds">' + seeds + '</div>' +
          '<div class="mid"><span class="pct num">' + pct.toFixed(0) + '%</span><span class="cap">本周期</span></div>' +
        '</div>' +
        '<div class="row"><span class="k">已用流量</span><span class="v num">' + bytes(used) + '</span></div>' +
        '<div class="row"><span class="k">套餐总量</span><span class="v num">' + (total > 0 ? bytes(total) : '不限') + '</span></div>' +
        '<div class="row"><span class="k">下次重置</span><span class="v">' +
          (sub.reset_day != null && sub.reset_day !== '' ? esc(sub.reset_day) + ' 天后' : '跟随套餐') + '</span></div>' +
      '</div>' +

      subscribeCard(sub) +
      '<div class="footer">© ' + new Date().getFullYear() + ' ' + esc(BRAND) + '</div>',
      { active:'/' }
    );

    if (sub.subscribe_url) drawQR(sub.subscribe_url);
  }).catch(function(e){
    if (!token()) return;
    render(errorBox(e.message), { active:'/' });
  });
}
/* 公告完全来自 /user/notice/fetch，没有公告就不渲染这块 */
var NOTICES = [], noticeIdx = 0;
function noticeCard(){
  if (!NOTICES.length) return '';
  var n = NOTICES[noticeIdx] || NOTICES[0];
  var many = NOTICES.length > 1;
  return '<div class="card" id="notice-card"><div class="notice">' +
    '<span class="bell">' + ic('bell', 22) + '</span>' +
    '<div style="flex:1;min-width:0">' +
      '<div style="display:flex;align-items:baseline;gap:10px;margin-bottom:6px">' +
        '<span style="font-weight:750;flex:1;min-width:0">' + esc(n.title || '公告') + '</span>' +
        (many ? '<span class="tag dim num">' + (noticeIdx + 1) + ' / ' + NOTICES.length + '</span>' : '') +
      '</div>' +
      (n.created_at ? '<div style="color:var(--faint);font-size:12px;margin-bottom:10px" class="num">' + date(n.created_at) + '</div>' : '') +
      '<div class="body" id="notice-body">' + (n.content || '') + '</div>' +
      '<div class="btn-row" style="margin-top:12px">' +
        '<button class="btn btn-sm btn-ghost" data-act="notice-toggle">展开全文</button>' +
        (many
          ? '<button class="btn btn-sm btn-ghost" data-act="notice-step" data-step="-1">上一条</button>' +
            '<button class="btn btn-sm btn-ghost" data-act="notice-step" data-step="1">下一条</button>'
          : '') +
      '</div>' +
    '</div></div></div>';
}

function statCard(icon, val, lab){
  return '<div class="stat"><div class="ico">' + ic(icon, 21) + '</div>' +
    '<div class="val">' + esc(val) + '</div><div class="lab">' + esc(lab) + '</div></div>';
}
function subscribeCard(sub){
  if (!sub.subscribe_url) {
    return '<div class="card"><h3 class="card-title">订阅链接</h3>' +
      '<p class="card-desc">未订阅用户不会显示订阅链接</p>' +
      '<div class="empty"><div class="dot">' + ic('info', 24) + '</div>' +
      '<h3>还没有订阅</h3><p>购买并开通套餐后，这里会显示完整订阅链接、复制按钮和订阅二维码。</p>' +
      '<a class="btn btn-primary btn-sm" href="#/plan">选择套餐' + ic('arrow', 16) + '</a></div></div>';
  }
  var u = sub.subscribe_url;
  var enc = encodeURIComponent(u);
  var name = encodeURIComponent(BRAND);
  var clients = [
    ['Clash',        'clash://install-config?url=' + enc + '&name=' + name],
    ['Shadowrocket', 'shadowrocket://add/sub://' + btoa(u).replace(/=/g, '') + '?remark=' + name],
    ['sing-box',     'sing-box://import-remote-profile?url=' + enc + '#' + name],
    ['Surge',        'surge:///install-config?url=' + enc],
    ['Loon',         'loon://import?sub=' + enc],
    ['Karing',       'karing://install-config?url=' + enc + '&name=' + name]
  ];
  return '<div class="card"><h3 class="card-title">订阅链接</h3>' +
    '<p class="card-desc">复制到客户端即可同步全部节点</p>' +
    '<div class="sub-url"><code id="sub-url">' + esc(u) + '</code>' +
      '<button class="btn btn-sm" data-act="copy-sub" data-url="' + esc(u) + '">' + ic('copy', 15) + '复制</button></div>' +
    '<div class="clients">' + clients.map(function(c){
      return '<a href="' + esc(c[1]) + '">' + esc(c[0]) + '</a>';
    }).join('') + '</div>' +
    '<div class="qr" id="qr-box"></div>' +
    (window.XG.tutorialUrl
      ? '<a class="btn btn-ghost btn-block btn-sm" style="margin-top:14px" target="_blank" rel="noopener" href="' +
        esc(window.XG.tutorialUrl) + '">查看使用教程</a>'
      : '') +
  '</div>';
}
function drawQR(text){
  var box = document.getElementById('qr-box');
  if (!box || typeof qrcode !== 'function') { if (box) box.style.display = 'none'; return; }
  try {
    var q = qrcode(0, 'M');
    q.addData(text);
    q.make();
    box.innerHTML = q.createImgTag(4, 0);
    var img = box.querySelector('img');
    if (img) { img.style.width = '172px'; img.style.height = '172px'; img.alt = '订阅二维码'; }
  } catch (e) { box.style.display = 'none'; }
}

/* ---------------- 套餐 ---------------- */
var PERIODS = [
  ['month_price',      'monthly',      '月付'],
  ['quarter_price',    'quarterly',    '季付'],
  ['half_year_price',  'half_yearly',  '半年付'],
  ['year_price',       'yearly',       '年付'],
  ['two_year_price',   'two_yearly',   '两年付'],
  ['three_year_price', 'three_yearly', '三年付'],
  ['onetime_price',    'onetime',      '一次性'],
  ['reset_price',      'reset_traffic','流量重置包']
];
var planSel = {};
function pagePlan(){
  render(loading(), { active:'/plan' });
  api('/user/plan/fetch').then(function(list){
    list = list || [];
    if (!list.length) {
      return render(sectionHead('套餐', '选择合适的周期，开通后立即生成订阅链接。') +
        '<div class="card"><div class="empty"><div class="dot">' + ic('info', 24) + '</div>' +
        '<h3>暂时没有可购买的套餐</h3><p>站点还没有上架套餐，稍后再来看看，或联系客服确认。</p></div></div>',
        { active:'/plan' });
    }
    var html = list.map(function(p, idx){
      var avail = PERIODS.filter(function(x){ return p[x[0]] != null && p[x[0]] !== ''; });
      if (!avail.length) return '';
      if (!planSel[p.id]) planSel[p.id] = avail[0][0];
      var cur = avail.filter(function(x){ return x[0] === planSel[p.id]; })[0] || avail[0];
      return '<div class="plan' + (idx === 0 && list.length > 1 ? ' hot' : '') + '">' +
        '<h3>' + esc(p.name) + '</h3>' +
        (p.transfer_enable ? '<span class="tag">' + p.transfer_enable + ' GB / 周期</span>' : '') +
        '<div class="price"><b>' + yuan(p[cur[0]]) + '</b><span>/ ' + cur[2] + '</span></div>' +
        '<div class="periods">' + avail.map(function(x){
          return '<button data-act="period" data-plan="' + p.id + '" data-key="' + x[0] + '"' +
            (x[0] === cur[0] ? ' class="on"' : '') + '>' + x[2] + ' ' + yuan(p[x[0]]) + '</button>';
        }).join('') + '</div>' +
        (p.content ? '<div class="body">' + p.content + '</div>' : '') +
        '<button class="btn btn-primary btn-block" data-act="buy" data-plan="' + p.id + '">立即购买</button>' +
      '</div>';
    }).join('');
    render(sectionHead('套餐', '选择合适的周期，开通后立即生成订阅链接。') + html, { active:'/plan' });
  }).catch(function(e){ render(errorBox(e.message), { active:'/plan' }); });
}
function buy(planId){
  var key = planSel[planId] || 'month_price';
  var alt = (PERIODS.filter(function(x){ return x[0] === key; })[0] || [])[1];
  toast('正在创建订单…');
  api('/user/order/save', { plan_id: Number(planId), period: key })
    .catch(function(){ return api('/user/order/save', { plan_id: Number(planId), period: alt }); })
    .then(function(tradeNo){
      go('/pay/' + (typeof tradeNo === 'string' ? tradeNo : (tradeNo && tradeNo.trade_no) || ''));
    })
    .catch(function(e){ toast(e.message, true); });
}

/* ---------------- 支付 ---------------- */
function pagePay(tradeNo){
  render(loading(), { active:'/plan' });
  Promise.all([
    api('/user/order/detail?trade_no=' + encodeURIComponent(tradeNo)),
    api('/user/payment/getPaymentMethod').catch(function(){ return []; })
  ]).then(function(r){
    var o = r[0] || {}, methods = r[1] || [];
    if (o.status === 3 || o.status === 1) {
      return render(sectionHead('订单', '') +
        '<div class="card"><div class="empty"><div class="dot">' + ic('check', 24) + '</div>' +
        '<h3>这笔订单已完成</h3><p>订阅已经开通，回到首页复制订阅链接即可。</p>' +
        '<a class="btn btn-primary btn-sm" href="#/">回到首页</a></div></div>', { active:'/plan' });
    }
    render(sectionHead('确认支付', '选择支付方式完成订单。') +
      '<div class="card">' +
        '<div class="row"><span class="k">订单号</span><span class="v num">' + esc(o.trade_no || tradeNo) + '</span></div>' +
        '<div class="row"><span class="k">套餐</span><span class="v">' + esc((o.plan && o.plan.name) || '—') + '</span></div>' +
        '<div class="row"><span class="k">应付金额</span><span class="v num" style="color:var(--melon-soft);font-size:20px">' +
          yuan(o.total_amount) + '</span></div>' +
      '</div>' +
      '<div class="card">' +
        '<h3 class="card-title">支付方式</h3><p class="card-desc">跳转到支付页面完成付款，付款后自动开通。</p>' +
        (methods.length
          ? methods.map(function(m){
              return '<button class="btn btn-block" style="margin-bottom:10px" data-act="checkout" data-method="' +
                m.id + '" data-trade="' + esc(o.trade_no || tradeNo) + '">' + esc(m.name) + '</button>';
            }).join('')
          : '<p class="card-desc">站点未配置在线支付，请联系客服处理这笔订单。</p>') +
        '<button class="btn btn-ghost btn-block btn-sm" style="margin-top:6px" data-act="cancel-order" data-trade="' +
          esc(o.trade_no || tradeNo) + '">取消订单</button>' +
      '</div>', { active:'/plan' });
  }).catch(function(e){ render(errorBox(e.message), { active:'/plan' }); });
}
function checkout(tradeNo, methodId){
  toast('正在跳转支付…');
  api('/user/order/checkout', { trade_no: tradeNo, method: Number(methodId) })
    .then(function(d){
      if (typeof d === 'string' && d.indexOf('http') === 0) { location.href = d; return; }
      if (d && d.type === 1 && d.data) { location.href = d.data; return; }
      if (d && d.data) { location.href = d.data; return; }
      toast('订单已提交，稍后在订单页查看状态');
      go('/order');
    })
    .catch(function(e){ toast(e.message, true); });
}

/* ---------------- 订单 ---------------- */
var ORDER_STATUS = { 0:['待支付','warn'], 1:['开通中','dim'], 2:['已取消','dim'], 3:['已完成','ok'], 4:['已折抵','dim'] };
function pageOrder(){
  render(loading(), { active:'/order' });
  api('/user/order/fetch').then(function(list){
    list = list || [];
    if (!list.length) {
      return render(sectionHead('订单', '所有购买记录都会保留在这里。') +
        '<div class="card"><div class="empty"><div class="dot">' + ic('order', 24) + '</div>' +
        '<h3>还没有订单</h3><p>选一个套餐开通，订单会出现在这里。</p>' +
        '<a class="btn btn-primary btn-sm" href="#/plan">选择套餐</a></div></div>', { active:'/order' });
    }
    var html = list.map(function(o){
      var st = ORDER_STATUS[o.status] || ['未知','dim'];
      var cls = st[1] === 'warn' ? 'tag warn' : (st[1] === 'ok' ? 'tag' : 'tag dim');
      return '<div class="item">' +
        '<div class="main"><div class="t">' + esc((o.plan && o.plan.name) || o.plan_name || '套餐') + '</div>' +
        '<div class="s">' + esc(o.trade_no) + ' · ' + date(o.created_at, true) + '</div></div>' +
        '<div style="text-align:right"><div class="num" style="font-weight:800">' + yuan(o.total_amount) + '</div>' +
        '<span class="' + cls + '" style="margin-top:5px">' + st[0] + '</span></div>' +
        (o.status === 0 ? '<a class="btn btn-sm btn-primary" href="#/pay/' + esc(o.trade_no) + '">去支付</a>' : '') +
      '</div>';
    }).join('');
    render(sectionHead('订单', '所有购买记录都会保留在这里。') + html, { active:'/order' });
  }).catch(function(e){ render(errorBox(e.message), { active:'/order' }); });
}

/* ---------------- 推广 ---------------- */
function pageInvite(){
  render(loading(), { active:'/invite' });
  api('/user/invite/fetch').then(function(d){
    d = d || {};
    var codes = d.codes || [];
    var stat = d.stat || [];
    var origin = location.origin;
    var link = codes.length ? origin + '/#/register?code=' + codes[0].code : '';
    var labels = ['已注册用户','有效邀请','佣金比例','确认中佣金','已发放佣金'];
    var fmt = function(i, v){
      if (i === 2) return (Number(v) || 0) + '%';
      if (i >= 3) return yuan(v);
      return String(Number(v) || 0);
    };
    render(sectionHead('推广', '把链接分享给朋友，成交后你会拿到返佣。') +
      '<div class="card">' +
        '<h3 class="card-title">我的邀请链接</h3>' +
        '<p class="card-desc">对方通过链接注册即视为你的邀请。</p>' +
        (link
          ? '<div class="sub-url"><code>' + esc(link) + '</code>' +
            '<button class="btn btn-sm" data-act="copy-sub" data-url="' + esc(link) + '">' + ic('copy', 15) + '复制</button></div>'
          : '<div class="empty" style="padding:22px 0"><div class="dot">' + ic('invite', 24) + '</div>' +
            '<h3>还没有邀请码</h3><p>生成一个邀请码，就能拿到专属链接。</p>' +
            '<button class="btn btn-primary btn-sm" data-act="gen-invite">生成邀请码</button></div>') +
      '</div>' +
      (stat.length
        ? '<div class="stat-grid" style="margin-top:14px">' + stat.slice(0, 5).map(function(v, i){
            return statCard(i >= 3 ? 'wallet' : 'invite', fmt(i, v), labels[i] || ('指标 ' + (i + 1)));
          }).join('') + '</div>'
        : '') +
      (codes.length > 1
        ? '<div class="card" style="margin-top:14px"><h3 class="card-title">全部邀请码</h3>' +
          codes.map(function(c){
            return '<div class="row"><span class="k num">' + esc(c.code) + '</span>' +
              '<button class="btn btn-sm" data-act="copy-sub" data-url="' + esc(origin + '/#/register?code=' + c.code) + '">复制链接</button></div>';
          }).join('') + '</div>'
        : ''),
      { active:'/invite' });
  }).catch(function(e){ render(errorBox(e.message), { active:'/invite' }); });
}

/* ---------------- 工单 ---------------- */
var TICKET_STATUS = { 0:'处理中', 1:'已关闭' };
function pageTicket(){
  render(loading(), { active:'/ticket' });
  api('/user/ticket/fetch').then(function(list){
    list = list || [];
    var body = list.length
      ? list.map(function(t){
          return '<a class="item" href="#/ticket/' + t.id + '">' +
            '<div class="main"><div class="t">' + esc(t.subject) + '</div>' +
            '<div class="s">#' + t.id + ' · ' + date(t.created_at, true) + '</div></div>' +
            '<span class="' + (t.status === 0 ? 'tag' : 'tag dim') + '">' + (TICKET_STATUS[t.status] || '—') + '</span>' +
          '</a>';
        }).join('')
      : '<div class="card"><div class="empty"><div class="dot">' + ic('ticket', 24) + '</div>' +
        '<h3>还没有工单</h3><p>遇到连接、订阅或账单问题，开一张工单，我们会在这里回复你。</p></div></div>';
    render(sectionHead('工单', '把遇到的问题描述清楚，能更快解决。') +
      '<button class="btn btn-primary btn-block" style="margin-bottom:16px" data-act="new-ticket">发起新工单</button>' +
      body, { active:'/ticket' });
  }).catch(function(e){ render(errorBox(e.message), { active:'/ticket' }); });
}
function pageTicketNew(){
  render(
    '<div style="padding:26px 0 16px"><a class="btn btn-sm btn-ghost" href="#/ticket">' + ic('back', 15) + '返回</a></div>' +
    sectionHead('发起新工单', '写清楚现象、时间和你用的客户端，处理会更快。') +
    '<div class="card">' +
      '<div class="field"><label for="tk-sub">主题</label><input id="tk-sub" placeholder="例如：香港节点连不上"></div>' +
      '<div class="field"><label for="tk-lv">紧急程度</label><select id="tk-lv">' +
        '<option value="0">普通</option><option value="1" selected>重要</option><option value="2">紧急</option></select></div>' +
      '<div class="field"><label for="tk-msg">问题描述</label>' +
        '<textarea id="tk-msg" placeholder="出现时间、使用的客户端和版本、节点名称、报错信息"></textarea></div>' +
      '<button class="btn btn-primary btn-block" data-act="submit-ticket">提交工单</button>' +
    '</div>', { active:'/ticket' });
}
function submitTicket(){
  var subject = (document.getElementById('tk-sub').value || '').trim();
  var level = Number(document.getElementById('tk-lv').value);
  var message = (document.getElementById('tk-msg').value || '').trim();
  if (!subject || !message) return toast('主题和描述都要填', true);
  var btn = document.querySelector('[data-act="submit-ticket"]');
  btn.disabled = true; btn.textContent = '提交中…';
  api('/user/ticket/save', { subject: subject, level: level, message: message })
    .then(function(){ toast('工单已提交'); go('/ticket'); })
    .catch(function(e){ toast(e.message, true); btn.disabled = false; btn.textContent = '提交工单'; });
}
function pageTicketDetail(id){
  render(loading(), { active:'/ticket' });
  api('/user/ticket/fetch?id=' + encodeURIComponent(id)).then(function(t){
    t = t || {};
    var msgs = (t.message || []).map(function(m){
      return '<div class="msg ' + (m.is_me ? 'me' : 'them') + '">' + esc(m.message) +
        '<span class="ts">' + date(m.created_at, true) + '</span></div>';
    }).join('');
    render(
      '<div style="padding:26px 0 16px"><a class="btn btn-sm btn-ghost" href="#/ticket">' + ic('back', 15) + '返回工单列表</a></div>' +
      '<h2 class="sec">' + esc(t.subject || ('工单 #' + id)) + '</h2>' +
      '<p class="sub">#' + esc(id) + ' · ' + (TICKET_STATUS[t.status] || '') + '</p>' +
      '<div class="card">' + (msgs || '<p class="card-desc">还没有消息。</p>') + '</div>' +
      (t.status === 0
        ? '<div class="card"><div class="field"><label for="tk-reply">回复</label>' +
          '<textarea id="tk-reply" placeholder="补充信息或反馈处理结果"></textarea></div>' +
          '<div class="btn-row"><button class="btn btn-primary" data-act="reply-ticket" data-id="' + esc(id) + '">发送回复</button>' +
          '<button class="btn btn-ghost" data-act="close-ticket" data-id="' + esc(id) + '">关闭工单</button></div></div>'
        : '<div class="card"><p class="card-desc" style="margin:0">这张工单已关闭。如果问题还在，请重新发起一张。</p></div>'),
      { active:'/ticket' });
  }).catch(function(e){ render(errorBox(e.message), { active:'/ticket' }); });
}

/* ---------------- 节点状态 ---------------- */
function pageNodes(){
  render(loading(), { active:'/' });
  api('/user/server/fetch').then(function(list){
    list = list || [];
    var now = Date.now() / 1000;
    var online = 0;
    var rows = list.map(function(s){
      var isOn = (s.is_online === 1 || s.is_online === true) ||
                 (s.last_check_at && (now - Number(s.last_check_at) < 300));
      if (isOn) online++;
      var tags = (s.tags || []).slice(0, 2).map(function(x){ return '<span class="tag dim">' + esc(x) + '</span>'; }).join(' ');
      return '<div class="node"><span class="led' + (isOn ? '' : ' off') + '"></span>' +
        '<span class="nm">' + esc(s.name) + '</span>' + tags +
        '<span class="rt">' + (s.type ? esc(s.type) + ' · ' : '') + 'x' + (s.rate || 1) + '</span></div>';
    }).join('');
    var pctOn = list.length ? Math.round(online / list.length * 100) : 0;
    render(
      '<div style="padding:26px 0 16px"><a class="btn btn-sm btn-ghost" href="#/">' + ic('back', 15) + '返回首页</a></div>' +
      sectionHead('节点状态', '在线状态、协议类型和倍率实时展示。') +
      '<div class="card">' +
        '<p class="eyebrow" style="margin-bottom:4px">节点在线</p>' +
        '<div style="font-size:44px;font-weight:800;letter-spacing:-.04em" class="num">' + online + ' / ' + list.length + '</div>' +
        '<div style="height:8px;border-radius:8px;background:var(--tint-dim);margin-top:14px;overflow:hidden">' +
          '<div style="height:100%;width:' + pctOn + '%;background:linear-gradient(90deg,var(--rind),var(--melon))"></div>' +
        '</div>' +
      '</div>' +
      '<div class="card">' + (rows || '<p class="card-desc" style="margin:0">订阅后才会显示节点列表。</p>') + '</div>',
      { active:'/' });
  }).catch(function(e){ render(errorBox(e.message), { active:'/' }); });
}

/* ---------------- 我的 ---------------- */
function pageMe(){
  render(loading(), { active:'/me' });
  Promise.all([
    api('/user/info'),
    api('/user/getSubscribe').catch(function(){ return {}; })
  ]).then(function(r){
    var info = r[0] || {}, sub = r[1] || {};
    render(sectionHead('我的', '账号信息与安全设置。') +
      '<div class="card">' +
        '<div class="row"><span class="k">邮箱</span><span class="v">' + esc(info.email || '—') + '</span></div>' +
        '<div class="row"><span class="k">当前套餐</span><span class="v">' + esc((sub.plan && sub.plan.name) || '未订阅') + '</span></div>' +
        '<div class="row"><span class="k">到期时间</span><span class="v num">' +
          (sub.expired_at ? date(sub.expired_at) : (sub.plan ? '长期有效' : '—')) + '</span></div>' +
        '<div class="row"><span class="k">账户余额</span><span class="v num">' + yuan(info.balance || 0) + '</span></div>' +
        '<div class="row"><span class="k">推广佣金</span><span class="v num">' + yuan(info.commission_balance || 0) + '</span></div>' +
        '<div class="row"><span class="k">上次登录</span><span class="v num">' + date(info.last_login_at, true) + '</span></div>' +
      '</div>' +

      '<div class="card">' +
        '<h3 class="card-title">修改密码</h3><p class="card-desc">修改后需要重新登录。</p>' +
        '<div class="field"><label for="pw-old">当前密码</label><input id="pw-old" type="password" autocomplete="current-password"></div>' +
        '<div class="field"><label for="pw-new">新密码</label><input id="pw-new" type="password" autocomplete="new-password" placeholder="至少 8 位"></div>' +
        '<button class="btn btn-primary btn-block" data-act="chpwd">保存新密码</button>' +
      '</div>' +

      '<div class="card">' +
        '<h3 class="card-title">重置订阅链接</h3>' +
        '<p class="card-desc">怀疑订阅被别人拿到时重置。重置后旧链接立即失效，需要在客户端重新导入。</p>' +
        '<button class="btn btn-ghost btn-block" data-act="reset-sub">重置订阅链接</button>' +
      '</div>' +

      '<div class="card">' +
        '<div class="btn-row">' +
          (window.XG.supportUrl ? '<a class="btn btn-sm" target="_blank" rel="noopener" href="' + esc(window.XG.supportUrl) + '">联系客服</a>' : '') +
          (window.XG.telegramUrl ? '<a class="btn btn-sm" target="_blank" rel="noopener" href="' + esc(window.XG.telegramUrl) + '">TG 群</a>' : '') +
          '<a class="btn btn-sm" href="#/nodes">节点状态</a>' +
        '</div>' +
        '<button class="btn btn-block btn-sm" style="margin-top:14px;color:var(--danger)" data-act="logout">退出登录</button>' +
      '</div>' +
      '<div class="footer">' + esc(BRAND) + ' · 主题版本 v' + esc(window.XG.version) + '</div>',
      { active:'/me' });
  }).catch(function(e){ render(errorBox(e.message), { active:'/me' }); });
}

/* ---------------- 事件代理 ---------------- */
document.addEventListener('click', function(ev){
  var el = ev.target.closest('[data-act]');
  if (!el) return;
  var act = el.getAttribute('data-act');

  if (act === 'theme')        { ev.preventDefault(); cycleTheme(); }
  else if (act === 'login')   { ev.preventDefault(); doLogin(); }
  else if (act === 'register'){ ev.preventDefault(); doRegister(); }
  else if (act === 'sendcode'){ ev.preventDefault(); sendCode(); }
  else if (act === 'reload')  { ev.preventDefault(); route(); }
  else if (act === 'copy-sub'){ ev.preventDefault(); copy(el.getAttribute('data-url')); }
  else if (act === 'notice-step') {
    ev.preventDefault();
    if (!NOTICES.length) return;
    noticeIdx = (noticeIdx + Number(el.getAttribute('data-step')) + NOTICES.length) % NOTICES.length;
    var card = document.getElementById('notice-card');
    if (card) card.outerHTML = noticeCard();
  }
  else if (act === 'notice-toggle') {
    ev.preventDefault();
    var b = document.getElementById('notice-body');
    b.classList.toggle('open');
    el.textContent = b.classList.contains('open') ? '收起' : '展开全文';
  }
  else if (act === 'period') {
    ev.preventDefault();
    planSel[el.getAttribute('data-plan')] = el.getAttribute('data-key');
    pagePlan();
  }
  else if (act === 'buy')      { ev.preventDefault(); buy(el.getAttribute('data-plan')); }
  else if (act === 'checkout') { ev.preventDefault(); checkout(el.getAttribute('data-trade'), el.getAttribute('data-method')); }
  else if (act === 'cancel-order') {
    ev.preventDefault();
    api('/user/order/cancel', { trade_no: el.getAttribute('data-trade') })
      .then(function(){ toast('订单已取消'); go('/order'); })
      .catch(function(e){ toast(e.message, true); });
  }
  else if (act === 'new-ticket')   { ev.preventDefault(); go('/ticket/new'); }
  else if (act === 'submit-ticket'){ ev.preventDefault(); submitTicket(); }
  else if (act === 'reply-ticket') {
    ev.preventDefault();
    var msg = (document.getElementById('tk-reply').value || '').trim();
    if (!msg) return toast('回复内容不能为空', true);
    api('/user/ticket/reply', { id: Number(el.getAttribute('data-id')), message: msg })
      .then(function(){ toast('已发送'); pageTicketDetail(el.getAttribute('data-id')); })
      .catch(function(e){ toast(e.message, true); });
  }
  else if (act === 'close-ticket') {
    ev.preventDefault();
    api('/user/ticket/close', { id: Number(el.getAttribute('data-id')) })
      .then(function(){ toast('工单已关闭'); pageTicketDetail(el.getAttribute('data-id')); })
      .catch(function(e){ toast(e.message, true); });
  }
  else if (act === 'gen-invite') {
    ev.preventDefault();
    api('/user/invite/save').then(function(){ toast('邀请码已生成'); pageInvite(); })
      .catch(function(e){ toast(e.message, true); });
  }
  else if (act === 'chpwd') {
    ev.preventDefault();
    var oldp = document.getElementById('pw-old').value || '';
    var newp = document.getElementById('pw-new').value || '';
    if (newp.length < 8) return toast('新密码至少 8 位', true);
    api('/user/changePassword', { old_password: oldp, new_password: newp })
      .then(function(){ toast('密码已更新，请重新登录'); setToken(''); go('/login'); })
      .catch(function(e){ toast(e.message, true); });
  }
  else if (act === 'reset-sub') {
    ev.preventDefault();
    if (!confirm('重置后旧订阅链接立即失效，需要在客户端重新导入。确定重置？')) return;
    api('/user/resetSecurity').then(function(){ toast('订阅链接已重置'); go('/'); })
      .catch(function(e){ toast(e.message, true); });
  }
  else if (act === 'logout') {
    ev.preventDefault();
    setToken('');
    toast('已退出登录');
    go('/landing');
  }
});

/* ---------------- 路由 ---------------- */
function currentPath(){
  var h = location.hash.replace(/^#/, '');
  if (!h) h = '/';
  return h.split('?')[0];
}
function route(){
  var p = currentPath();
  var authed = !!token();

  if (p === '/login')    return pageLogin();
  if (p === '/register') return pageRegister();
  if (p === '/landing')  return pageLanding();

  if (!authed) return pageLanding();

  if (p === '/' || p === '')          return pageHome();
  if (p === '/plan')                  return pagePlan();
  if (p.indexOf('/pay/') === 0)       return pagePay(decodeURIComponent(p.slice(5)));
  if (p === '/order')                 return pageOrder();
  if (p === '/invite')                return pageInvite();
  if (p === '/ticket')                return pageTicket();
  if (p === '/ticket/new')            return pageTicketNew();
  if (p.indexOf('/ticket/') === 0)    return pageTicketDetail(p.slice(8));
  if (p === '/nodes')                 return pageNodes();
  if (p === '/me')                    return pageMe();

  return pageHome();
}
applyTheme(themeMode());
window.addEventListener('hashchange', route);
route();

})();
</script>
{!! $theme_config['custom_html'] ?? '' !!}
</body>
</html>
